setwd("D:\\2nd Year\\1st Semester\\Probability and Statistics - IT2120\\Lab\\LAB 08\\IT24103321")
getwd()

# 1.
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

# Calculate the population mean.
population_mean <- mean(weights$Weight.kg)

# Calculate the population standard deviation.
population_sd <- sd(weights$Weight.kg)

# Print the results.
print(paste("Population Mean:", population_mean))
print(paste("Population Standard Deviation:", population_sd))


# 2.
# Create null vectors to store the sample means and standard deviations.
sample_means <- c()
sample_sds <- c()

# Loop 25 times to draw samples.
for (i in 1:25) {
  # Draw a random sample of size 6 with replacement.
  sample_data <- sample(weights$Weight.kg, 6, replace = TRUE)
  
  # Calculate and store the sample mean.
  sample_means[i] <- mean(sample_data)
  
  # Calculate and store the sample standard deviation.
  sample_sds[i] <- sd(sample_data)
}

# 3.
# Calculate the mean of the sample means.
mean_of_sample_means <- mean(sample_means)

# Calculate the standard deviation of the sample means.
sd_of_sample_means <- sd(sample_means)

# Print the results.
print(paste("Mean of Sample Means:", mean_of_sample_means))
print(paste("Standard Deviation of Sample Means:", sd_of_sample_means))

